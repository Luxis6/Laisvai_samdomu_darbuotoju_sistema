<?php declare(strict_types=1);

namespace App\Factories;

class OrderFactory extends BaseFactory
{
}
