<?php
return [
    'error' => 'Error!',
    'edit' => 'Edit Category',
    'name' => 'Category Name',
    'close' => 'Close',
    'update' => 'Update',
    'title' => 'Categories',
    'delete' => 'Delete',
    'create' => 'Create Category',
    'parent' => 'Select Parent Category',
];
