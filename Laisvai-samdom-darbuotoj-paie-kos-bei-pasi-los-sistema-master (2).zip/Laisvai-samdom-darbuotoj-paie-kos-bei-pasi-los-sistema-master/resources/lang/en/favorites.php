<?php
return [
    'add' => 'Add to favorites',
    'remove' => 'Remove from favorites'
];
