<?php
return [
    'submit' => 'Submit'
];
