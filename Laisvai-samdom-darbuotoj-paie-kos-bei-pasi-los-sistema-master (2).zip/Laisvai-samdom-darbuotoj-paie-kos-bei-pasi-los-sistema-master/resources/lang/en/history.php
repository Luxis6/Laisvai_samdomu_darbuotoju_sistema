<?php
return [
    'url' => 'URL',
    'date' => 'Date'
];
