<?php
return [
    'home' => 'Home',
    'post' => 'Post an advert',
    'login' => 'Login',
    'register' => 'Register'
];
