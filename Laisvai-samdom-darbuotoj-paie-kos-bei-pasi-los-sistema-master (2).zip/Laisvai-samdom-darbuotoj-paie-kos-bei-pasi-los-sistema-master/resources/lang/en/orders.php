<?php
return [
    'order' => 'Order',
    'service_title' => 'Service title',
    'service_price' => 'Service price',
    'requirements' => 'Requirements',
    'orders_tab' => 'My Orders',
    'services_tab' => 'My services orders',
    'no_orders' => 'You haven\'t ordered anything yet',
    'no_services' => 'Noone ordered anything from you',
    'already_bought' => 'Already bought',
    'category' => 'Category',
    'order_details' => 'Order details',
    'total' => 'Order Total'
];
