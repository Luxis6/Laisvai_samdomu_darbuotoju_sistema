<?php
return [
    'search' => 'Search',
    'submit' => 'Submit',
    'number' => 'Contact support',
    'location' => 'Our location',
    'email' => 'Contact email',
    'about_us' => 'About Us',
    'intro_heading' => 'Welcome to the future!',
    'intro_subtitle' => 'In the future most of todays works will be done by freelancers',
    'watch' => 'Watch Video',
    'intro' => 'Freelancers\' work search system',
    'intro_subtext' => 'It is tomorrow - today',
    'intro_text' => 'In the future most of todays\' works will be done by freelancers',
    'trusted' => 'Trusted By',
    'courses' => 'Services',
    'all' => 'All',
    'home' => 'Home',
    'total' => 'Total',
    'admin' => 'Admin panel'
];
