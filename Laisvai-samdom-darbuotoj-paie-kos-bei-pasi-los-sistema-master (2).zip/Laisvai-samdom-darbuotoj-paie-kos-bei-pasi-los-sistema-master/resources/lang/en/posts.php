<?php
return [
    'title' => 'Recent adverts',
    'none' => 'We haven\'t found any posts that match your search criteria',
    //Create
    'Create a new post' => 'Create a new post',
    'Title' => 'Title',
    'Content' => 'Content',
    'Category' => 'Category',
    'Publish' => 'Publish',
    'Select category' => 'Select category',
    'New post' => 'New post',
    'Edit' => 'Edit',
    'Update' => 'Update',
    'posted' => 'Posted:',
    'Delete' => 'Delete',
    'price' => 'Price',
    'image' => 'Image',
    'category' => 'Category'
];
