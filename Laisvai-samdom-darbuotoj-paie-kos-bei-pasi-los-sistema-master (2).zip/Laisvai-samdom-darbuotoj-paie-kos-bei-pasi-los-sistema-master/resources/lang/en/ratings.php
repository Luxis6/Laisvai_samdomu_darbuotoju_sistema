<?php
return [
    'title' => 'Rating',
    'choose_vote' => 'Choose vote',
    'vote' => 'Vote',
    'votes' => 'votes',
    'comment' => 'Your comment',
    'latest' => 'Latest reviews',
    'delete' => 'Delete',
    'edit' => 'Edit',
    'sortbydate' => 'Sort by date',
    'sortbyvote' => 'Sort by vote'
];
