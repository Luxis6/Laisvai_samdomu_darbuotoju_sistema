<?php
return [
    'results_title' => 'Search results',
    'results' => 'Showing results for query'
];
