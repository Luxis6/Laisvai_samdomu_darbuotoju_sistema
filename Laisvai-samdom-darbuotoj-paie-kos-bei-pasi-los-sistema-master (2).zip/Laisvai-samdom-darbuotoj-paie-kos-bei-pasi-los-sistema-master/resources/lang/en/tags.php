<?php
return [
    'tags' => 'Tags',
    'delimiter' => '(separated by commas)'
];
