<?php
return [
    'error' => 'Klaida!',
    'edit' => 'Redaguoti kategoriją',
    'name' => 'Kategorijos pavadinimas',
    'close' => 'Uždaryti',
    'update' => 'Atnaujinti',
    'title' => 'Kategorijos',
    'delete' => 'Ištrinti',
    'create' => 'Sukurti kategoriją',
    'parent' => 'Pasirinkite tėvininę kategoriją',
];
