<?php
return [
    'add' => 'Pridėti prie mėgstamiausių',
    'remove' => 'Ištrinti iš mėgstamiausių'
];
