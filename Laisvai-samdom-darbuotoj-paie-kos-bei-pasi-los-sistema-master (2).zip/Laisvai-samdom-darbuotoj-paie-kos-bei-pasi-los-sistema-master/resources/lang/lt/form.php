<?php
return [
    'submit' => 'Patvirtinti'
];
