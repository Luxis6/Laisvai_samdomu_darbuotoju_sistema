<?php
return [
    'url' => 'Adresas',
    'date' => 'Data'
];
