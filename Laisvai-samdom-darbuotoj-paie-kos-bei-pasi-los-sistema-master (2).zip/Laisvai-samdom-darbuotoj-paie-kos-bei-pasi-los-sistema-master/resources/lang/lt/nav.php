<?php
return [
    'home' => 'Namai',
    'post' => 'Paskelbk skelbimą',
    'login' => 'Prisijungti',
    'register' => 'Registruotis'
];
