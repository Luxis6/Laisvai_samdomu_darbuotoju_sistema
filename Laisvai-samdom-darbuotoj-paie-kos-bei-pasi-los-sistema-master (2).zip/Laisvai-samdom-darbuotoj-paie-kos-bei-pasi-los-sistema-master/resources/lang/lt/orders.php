<?php
return [
    'order' => 'Užsakyti',
    'service_title' => 'Paslaugos pavadinimas',
    'service_price' => 'Paslaugos kaina',
    'requirements' => 'Papildomi pageidavimai',
    'orders_tab' => 'Mano užsakymai',
    'services_tab' => 'Mano paslaugų užsakymai',
    'no_orders' => 'Užsakymų nėra',
    'no_services' => 'Jūsų paslaugų užsakymų nėra',
    'already_bought' => 'Jau nusipirko',
    'category' => 'Kategorija',
    'order_details' => 'Užsakymo informacija',
    'total' => 'Viso'
];
