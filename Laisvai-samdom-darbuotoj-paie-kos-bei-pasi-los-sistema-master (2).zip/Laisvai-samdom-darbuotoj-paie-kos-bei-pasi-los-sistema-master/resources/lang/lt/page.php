<?php
return [
    'search' => 'Paieška',
    'submit' => 'Patvirtinti',
    'number' => 'Pagalba',
    'location' => 'Mūsų vieta',
    'email' => 'Mūsų el. paštas',
    'about_us' => 'Apie mus',
    'intro_heading' => 'Sveikas atvykęs į ateitį!',
    'intro_subtitle' => 'Ateityje dauguma dabartinių įmonių darbų darys laisvai samdomi darbuotojai',
    'watch' => 'Peržiūrėk įrašą',
    'intro' => 'Laisvai samdomų darbuotojų darbo sistema',
    'intro_subtext' => 'Tai - atetis šiandien',
    'intro_text' => 'LSD - laisvai samdomi darbuotoja, yra mūsų ateitis, dauguma dabartinių įmonių darbų bus
    atliekama būtent jų pagalba.',
    'trusted' => 'Pasitiki',
    'courses' => 'Skelbimai',
    'all' => 'Visi',
    'home' => 'Namai',
    'total' => 'Viso',
    'admin' => 'Administravimas'
];
