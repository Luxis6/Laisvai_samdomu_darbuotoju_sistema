<?php
return [
    'title' => 'Naujausi skelbimai',
    'none' => 'Ieškomų įrašų nėra',
    //Create
    'Create a new post' => 'Įrašo kūrimas',
    'Title' => 'Pavadinimas',
    'Content' => 'Turinys',
    'Category' => 'Kategorija',
    'Publish' => 'Patvirtinti',
    'Select category' => 'Pasirinkite kategoriją',
    'New post' => 'Naujas įrašas',
    'Edit' => 'Redaguoti',
    'Update' => 'Atnaujinti',
    'posted' => 'Paskelbta:',
    'Delete' => 'Ištrinti',
    'price' => 'Kaina',
    'image' => 'Nuotrauka',
    'category' => 'Kategorija'
];
