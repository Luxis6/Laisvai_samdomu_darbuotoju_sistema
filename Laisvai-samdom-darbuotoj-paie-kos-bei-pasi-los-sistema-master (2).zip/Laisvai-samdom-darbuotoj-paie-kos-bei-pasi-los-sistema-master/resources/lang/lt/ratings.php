<?php
return [
    'title' => 'Ivertinimas',
    'choose_vote' => 'Pasirinkite balsą',
    'vote' => 'Balsuoti',
    'votes' => 'balsų',
    'comment' => 'Jūsų komentaras',
    'latest' => 'Paskutiniai vertinimai',
    'delete' => 'Trinti',
    'edit' => 'Redaguoti',
    'sortbydate' => 'Rūšiuoti pagal datą',
    'sortbyvote' => 'Rūšiuoti pagal balsą'
];
