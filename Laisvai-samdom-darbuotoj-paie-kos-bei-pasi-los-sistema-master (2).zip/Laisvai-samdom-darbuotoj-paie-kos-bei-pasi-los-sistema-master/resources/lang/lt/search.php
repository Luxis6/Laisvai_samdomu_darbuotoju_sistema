<?php
return [
    'results_title' => 'Paieškos rezultatai',
    'results' => 'Rodomi paieškos rezultatai užklausai'
];
