<?php
return [
    'tags' => 'Žymės',
    'delimiter' => '(atskirtos kableliais)'
];
