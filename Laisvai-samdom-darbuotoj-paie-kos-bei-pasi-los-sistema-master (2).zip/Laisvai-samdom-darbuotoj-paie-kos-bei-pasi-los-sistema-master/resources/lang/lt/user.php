<?php
return [
    'change_pass' => 'Keisti slaptažodį',
    'logout' => 'Atsijungti',
    'password' => 'Slaptažodis',
    'new_password' => 'Naujas slaptažodis',
    'confirm_new_password' => 'Patvirtinkite naują slaptažodį',
    'wrong_pass' => 'Įvestas slaptažodis yra neteisingas',
    'pass_changed' => 'Slaptažodis pakeistas sėkmingai',
    'history' => 'Naršymo istorija',
    'my_account' => 'Mano paskyra',
    'hello' => 'Labas',
    'not' => 'ne',
    'edit' => 'Profilio redagavimas',
    'password_change' => 'Slaptažodžio keitimas (nepildyti jei nekeisite)',
    'email' => 'El. Paštas',
    'name' => 'Vardas',
    'save' => 'Išsaugoti pakeitimus',
    'password_incorrect' => 'Slaptažodis neteisingas',
    'passwords_not_match' => 'Slaptažodžiai nesutampa',
    'profile_updated' => 'Profilis atnaujintas',
    'photo' => 'Nuotrauka'
];
